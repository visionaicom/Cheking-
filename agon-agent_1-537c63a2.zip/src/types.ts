export interface Resume {
  id: number;
  user_id: string;
  title: string;
  job_title: string;
  company: string;
  content: ResumeContent;
  created_at: string;
  updated_at?: string;
}

export interface ResumeContent {
  name: string;
  email: string;
  phone: string;
  linkedin: string;
  summary: string;
  experience: Experience[];
  education: Education[];
  skills: string[];
}

export interface Experience {
  company: string;
  role: string;
  startDate: string;
  endDate: string;
  description: string;
}

export interface Education {
  institution: string;
  degree: string;
  year: string;
  gpa?: string;
}
